#include "WordFreq.h"
#include <vector>

///-----------------------------------------------------------------
/// Process the given text file and return the most frequent "k" words
///
vector<WordFreq> GetMostFrequentKWords(string filename, int k) {
	vector<WordFreq> result;

	// Fill this in

	return result;
} //end-GetMostFrequentKWords